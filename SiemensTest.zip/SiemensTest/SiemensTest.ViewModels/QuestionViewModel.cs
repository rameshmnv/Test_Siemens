﻿using SiemensTest.DataLayer;
using SiemensTest.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace SiemensTest.ViewModels
{
    public class QuestionViewModel : ContentPageBase
    {
        #region Private variables

        private MainViewModel MainViewModel;
        public int CorrectAnswers = 0;
        private int DisplayedQuestion = 0;
        private bool isReview = false;
        private List<QuestionModel> all_questions;
        private string question;
        private string isNextButtonEnable = true.ToString();
        private ObservableCollection<OptionModel> optionList;

        #endregion

        #region Relay commands
        public RelayCommand<int> NextCommand => new RelayCommand<int>(Next);
        public RelayCommand<int> SkipCommand => new RelayCommand<int>(Skip);

        #endregion

        #region Properties

        public List<int> skippedQuestions = new List<int>();

        public string Question
        {
            get
            {
                return question;
            }
            set
            {
                question = value;
                OnPropertyChanged("Question");
            }
        }

        public string IsNextButtonEnable
        {
            get
            {
                return isNextButtonEnable;
            }
            set
            {
                isNextButtonEnable = value;
                OnPropertyChanged("IsNextButtonEnable");
            }
        }

        public ObservableCollection<OptionModel> OptionList
        {
            get
            {
                return optionList;
            }
            set
            {
                optionList = value;
                OnPropertyChanged("OptionList");
            }
        }

        #endregion

        #region Constructor
        public QuestionViewModel(MainViewModel mainViewModel) : base(nameof(QuestionViewModel))
        {
            MainViewModel = mainViewModel;
            DefaultMethod();
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Default Method
        /// </summary>
        private void DefaultMethod()
        {
            try
            {
                var Questions = new Data().Questions;

                var rnd = new Random();

                all_questions = Questions.OrderBy(x => rnd.Next()).Take(10).ToList();
                Question = string.Format(Resources.Question_Format, 1, all_questions[0].Question);
                OptionList = new ObservableCollection<OptionModel>(all_questions[0].Options.OrderBy(x => rnd.Next()));
            }
            catch
            {
                // Exception handling
            }
        }

        /// <summary>
        /// Next button Click event.
        /// </summary>
        /// <param name="obj"></param>
        private void Next(int obj)
        {
            try
            {
                if (OptionList.FirstOrDefault(op => op.IsOptionSelected == true.ToString()) == null)
                {
                    MainViewModel.ErrorMessage = Resources.No_Option_Error_Msg;
                    return;
                }
                if (OptionList.First(op => op.IsOptionSelected == true.ToString()).IsCorrectOption)
                {
                    CorrectAnswers++;
                }


                if (isReview)
                {
                    if (DisplayedQuestion < skippedQuestions.Count)
                    {
                        DisplayNextQuestion(skippedQuestions[DisplayedQuestion]);
                        DisplayedQuestion++;
                    }
                }
                else
                {
                    if (MainViewModel != null)
                        MainViewModel.UpdateProgress((DisplayedQuestion + 1) * 10, DisplayedQuestion);
                    if (DisplayedQuestion < 10)
                    {
                        DisplayNextQuestion(DisplayedQuestion);
                        DisplayedQuestion++;
                    }
                    else
                    {
                        IsNextButtonEnable = false.ToString();
                    }
                }
            }
            catch
            {
                // Exception handling as per the required
            }
        }

        private void Skip(int obj)
        {
            try
            {
                skippedQuestions.Add(DisplayedQuestion);
                DisplayNextQuestion(DisplayedQuestion);
                DisplayedQuestion++;
            }
            catch
            {
                // Exception handling as per the required
            }
        }

        private void DisplayNextQuestion(int questionNumber)
        {
            Question = string.Format(Resources.Question_Format, questionNumber + 2, all_questions[questionNumber + 1].Question);
            OptionList = all_questions[questionNumber + 1].Options;
            var rnd = new Random();
            OptionList = new ObservableCollection<OptionModel>(all_questions[questionNumber + 1].Options.OrderBy(x => rnd.Next()));
        }

        #endregion

        #region public methods

        public void ReviewOfquestions()
        {
            IsNextButtonEnable = true.ToString();
            DisplayedQuestion = 0;
            isReview = true;
            DisplayNextQuestion(skippedQuestions[0] - 1);
        }

        #endregion
    }
}

