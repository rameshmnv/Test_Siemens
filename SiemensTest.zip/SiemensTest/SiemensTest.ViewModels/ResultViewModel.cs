﻿using SiemensTest.Models;

namespace SiemensTest.ViewModels
{
    public class ResultViewModel : ContentPageBase
    {
        public string Message { get; set; }

        public string Date { get; set; }

        public string MessageColor { get; set; }
        public ResultViewModel(CandidateModel candidateModel) : base(nameof(ResultViewModel))
        {
            
        }

        public void UpdateStatus(CandidateModel candidateModel)
        {
            Date = "Exam date: " + candidateModel.ExamDate.Date.ToString("dd - MM - yyyy.");
            if (candidateModel.ExamResult)
            {
                Message = "Congratulations!!! You have successfully cleared the test.";
                MessageColor = "Green";
            }
            else
            {
                Message = "Sorry!!! You have not cleared the test. Please try again...!";
                MessageColor = "Red";
            }
        }
    }
}

