﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensTest.ViewModels
{
    public class ContentPageBase : BaseViewModel, IContentPage
    {
        public ContentPageBase(string title)
        {
            Title = title;
        }

        public string Title { get; }
    }
}

