﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensTest.ViewModels
{
    public class CandidateInfoViewModel : ContentPageBase
    {
        private string userName;

        public string UserName
        {
            get { return userName; }
            set
            {
                userName = value;
                OnPropertyChanged("UserName");
            }
        }

        public CandidateInfoViewModel() : base(nameof(CandidateInfoViewModel))
        {
        }

    }
}
