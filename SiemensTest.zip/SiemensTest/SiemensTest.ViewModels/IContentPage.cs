﻿namespace SiemensTest.ViewModels
{
    public interface IContentPage
    {
        string Title { get; }
    }
}
