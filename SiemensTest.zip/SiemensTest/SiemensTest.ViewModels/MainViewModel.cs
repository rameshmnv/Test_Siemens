﻿using SiemensTest.Models;
using System;
using System.Collections.Generic;
using System.Windows.Threading;

namespace SiemensTest.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        #region Private Variables

        private CandidateModel candidateModel = new CandidateModel();
        private int currentpageno = 0;
        private IContentPage content;
        private string welcome_Message;
        private string isSubmitEnable = true.ToString();
        private string errorMessage;
        private string questionProgress;
        private int progressValue;
        private string remaingTime;
        private TimeSpan time = TimeSpan.FromMinutes(10);
        private bool IsTimeout = false;
        private string timerColor = Resources.Black_Text;
        private readonly Dictionary<int, Lazy<IContentPage>> contentPages;
        private DispatcherTimer timer = new DispatcherTimer();
        private bool IsreviewDone = false;
        private string progressVisibility = Resources.Hidden_Text;


        #endregion

        #region Properties
        public IContentPage Content { get => content; set => Set(ref content, value); }

        public string Welcome_Message
        {
            get
            {
                return welcome_Message;
            }
            set
            {
                welcome_Message = value;
                OnPropertyChanged("Welcome_Message");
            }
        }

        public string ProgressVisibility
        {
            get
            {
                return progressVisibility;
            }
            set
            {
                progressVisibility = value;
                OnPropertyChanged("ProgressVisibility");
            }
        }

        public string IsSubmitEnable
        {
            get
            {
                return isSubmitEnable;
            }
            set
            {
                isSubmitEnable = value;
                OnPropertyChanged("IsSubmitEnable");
            }
        }

        public string ErrorMessage
        {
            get
            {
                return errorMessage;
            }
            set
            {
                errorMessage = value;
                OnPropertyChanged("ErrorMessage");
            }
        }

        public string QuestionProgress
        {
            get
            {
                return questionProgress;
            }
            set
            {
                questionProgress = value;
                OnPropertyChanged("QuestionProgress");
            }
        }

        public int ProgressValue
        {
            get
            {
                return progressValue;
            }
            set
            {
                progressValue = value;
                OnPropertyChanged("ProgressValue");
            }
        }

        public string Remaing_Time
        {
            get
            {
                return remaingTime;
            }
            set
            {
                remaingTime = value;
                OnPropertyChanged("Remaing_Time");
            }
        }

        public string Timer_Color
        {
            get
            {
                return timerColor;
            }
            set
            {
                timerColor = value;
                OnPropertyChanged("Timer_Color");
            }
        }

        #endregion

        #region Relay Commands

        public RelayCommand<int> SubmitCommand => new RelayCommand<int>(Submit);

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor for main view model
        /// </summary>
        public MainViewModel()
        {
            contentPages = new Dictionary<int, Lazy<IContentPage>>
            {
                [1] = new Lazy<IContentPage>(() => new CandidateInfoViewModel()),
                [2] = new Lazy<IContentPage>(() => new QuestionViewModel(this)),
                [3] = new Lazy<IContentPage>(() => new ResultViewModel(candidateModel)),
            };
            Content = contentPages[1].Value;

            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Timer running method to update the test time management.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            Remaing_Time = string.Format(Resources.Rem_Time, time.ToString());
            time = time - TimeSpan.FromSeconds(1);

            if (time < TimeSpan.FromMinutes(1))
            {
                Timer_Color = Resources.Red_Text;
            }

            if (time < TimeSpan.FromSeconds(1))
            {
                IsTimeout = true;
                time = TimeSpan.FromSeconds(0);
                Submit(2);
            }
        }

        /// <summary>
        /// Action for the Submit button
        /// </summary>
        /// <param name="value"></param>
        private void Submit(int value)
        {
            try
            {
                if (currentpageno == 0 && !string.IsNullOrEmpty(((CandidateInfoViewModel)contentPages[1].Value).UserName))
                {
                    Content = contentPages[2].Value;
                    Welcome_Message = string.Format(Resources.Welcome_Note_Text, ((CandidateInfoViewModel)contentPages[1].Value).UserName);
                    candidateModel.ExamDate = DateTime.Today.Date;
                    currentpageno = 1;
                    ErrorMessage = string.Empty;
                    timer.Start();
                    ProgressVisibility = Resources.Visible_Text;
                }
                else if (Content == contentPages[2].Value && ((QuestionViewModel)contentPages[2].Value).OptionList != null)
                {
                    if (((QuestionViewModel)contentPages[2].Value).skippedQuestions.Count > 0 && !IsreviewDone)
                    {
                        ErrorMessage = Resources.Review_Msg_Text;
                        IsreviewDone = true;
                        ((QuestionViewModel)contentPages[2].Value).ReviewOfquestions();
                    }
                    else
                    {
                        if (((QuestionViewModel)contentPages[2].Value).CorrectAnswers >= 5)
                        {
                            candidateModel.ExamResult = true;
                        }
                        ((ResultViewModel)contentPages[3].Value).UpdateStatus(candidateModel);
                        Content = (ResultViewModel)contentPages[3].Value;
                        timer.Stop();

                        IsSubmitEnable = false.ToString();
                        ErrorMessage = string.Empty;
                    }
                }
                else if (!IsTimeout)
                {
                    ErrorMessage = Resources.UserName_Error_Text;
                }
            }
            catch (Exception ex)
            {
                // Logging exceptions by using Logger mechanism.
            }
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Progress bar status update method.
        /// </summary>
        /// <param name="progress"></param>
        /// <param name="question_no"></param>
        public void UpdateProgress(int progress, int question_no)
        {
            try
            {
                ProgressValue = progress;
                QuestionProgress = string.Format(Resources.Progress_Text, question_no + 1);
            }
            catch (Exception ex)
            {
                // Logging exceptions by using Logger mechanism.
            }
        }

        #endregion
    }
}

