﻿using System;

namespace SiemensTest.Models
{
    public class CandidateModel
    {
        public string UserName { get; set; }
        public DateTime ExamDate { get; set; }
        public bool ExamResult { get; set; }
    }
}
