﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensTest.Models
{
    public class OptionModel
    {
        public string Option { get; set; }
        public string IsOptionSelected { get; set; }

        public bool IsCorrectOption { get; set; }

    }
}
