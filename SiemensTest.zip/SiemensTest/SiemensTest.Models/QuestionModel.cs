﻿using System.Collections.ObjectModel;

namespace SiemensTest.Models
{
    public class QuestionModel
    {
        public string Question { get; set; }
        public ObservableCollection<OptionModel> Options { get; set; }
        
    }
}
