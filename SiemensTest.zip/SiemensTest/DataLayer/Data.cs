﻿using SiemensTest.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensTest.DataLayer
{
    public class Data
    {
        public List<QuestionModel> Questions = new List<QuestionModel>();

        public const string questionsString = "1+1 ? 2 3 4 5 2," + "2+1 ? 2 3 4 5 3," + "3+1 ? 2 3 4 5 4," +
            "4+1 ? 2 3 4 5 5," + "5+1 ? 6 3 4 5 6," + "6+1 ? 7 3 4 5 7," + "7+1 ? 8 3 4 5 8," +
            "8+1 ? 9 3 4 5 9," + "9+1 ? 10 3 4 5 10," + "10+1 ? 11 3 4 5 11," + "11+1 ? 12 3 4 5 12," +
            "12+1 ? 13 3 4 5 13," + "13+1 ? 14 3 4 5 14," + "14+1 ? 15 3 4 5 15," + "15+1 ? 16 3 4 5 16," +
            "16+1 ? 17 3 4 5 17," + "17+1 ? 18 3 4 5 18," + "18+1 ? 19 3 4 5 19," + "19+1 ? 20 3 4 5 20," +
            "20+1 ? 21 3 4 5 21";

        public Data()
        {
            DefaultMethod();
        }

        private void DefaultMethod()
        {
            var question_parts = questionsString.Split(',');

            foreach (string question in question_parts)
            {
                QuestionModel qestionModel = new QuestionModel();
                var quest_and_opt = question.Split('?');
                qestionModel.Question = quest_and_opt[0];
                var optionString = quest_and_opt[1].TrimStart().Split(' ');
                int i = 0;
                ObservableCollection<OptionModel> options = new ObservableCollection<OptionModel>();
                foreach (string option in optionString)
                {
                    if (i == 4)
                        break;
                    OptionModel optionModel = new OptionModel
                    {
                        Option = option,
                        IsOptionSelected = "False"
                    };
                    if (option == optionString.Last())
                        optionModel.IsCorrectOption = true;
                    i++;
                    options.Add(optionModel);
                }

                qestionModel.Options = options;
                Questions.Add(qestionModel);
            }
        }
    }
}
