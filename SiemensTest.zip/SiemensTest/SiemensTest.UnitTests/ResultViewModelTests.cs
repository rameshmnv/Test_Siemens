﻿using NUnit.Framework;
using SiemensTest.Models;
using SiemensTest.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensTest.UnitTests
{
    [TestFixture]
    public class ResultViewModelTests
    {
        [Test]
        public void ExamResultWhenExamPassedTest()
        {
            var candidateObj = new CandidateModel() { ExamDate = DateTime.Today, ExamResult = true };

            ResultViewModel TestObject = new ResultViewModel(candidateObj);

            TestObject.UpdateStatus(candidateObj);

            Assert.AreEqual("Green", TestObject.MessageColor);
        }

        [Test]
        public void ExamResultWhenExamFailedTest()
        {
            var candidateObj = new CandidateModel() { ExamDate = DateTime.Today, ExamResult = false };

            ResultViewModel TestObject = new ResultViewModel(candidateObj);

            TestObject.UpdateStatus(candidateObj);

            Assert.AreEqual("Red", TestObject.MessageColor);
        }
    }
}
